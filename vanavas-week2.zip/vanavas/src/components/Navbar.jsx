import { useState, useEffect } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'

function VanaVasLogo() {
  return (
    <Link to="/" className="flex items-center gap-2.5 group">
      <svg width="38" height="38" viewBox="0 0 80 80" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0">
        <circle cx="40" cy="40" r="38" fill="#1a4a31"/>
        <polygon points="40,10 58,38 22,38" fill="#e8f5ee" opacity="0.5"/>
        <polygon points="40,13 60,42 20,42" fill="#2d7a4f"/>
        <polygon points="40,13 48,26 32,26" fill="#ffffff" opacity="0.9"/>
        <polygon points="25,55 30,42 35,55" fill="#1D6B3E"/>
        <polygon points="33,55 40,40 47,55" fill="#236040"/>
        <polygon points="45,55 50,42 55,55" fill="#1D6B3E"/>
        <ellipse cx="40" cy="57" rx="28" ry="6" fill="#236040"/>
        <circle cx="22" cy="22" r="5" fill="#f5c842" opacity="0.9"/>
      </svg>
      <div className="flex flex-col leading-none">
        <span style={{ fontFamily: "Georgia, serif" }} className="text-xl font-bold text-[#1a4a31] tracking-tight">
          Vana<span className="text-[#2d7a4f]">Vas</span>
        </span>
        <span className="text-[9px] tracking-[2px] text-[#a96f2b] uppercase font-medium mt-0.5">
          Uttarakhand
        </span>
      </div>
    </Link>
  )
}

const links = [
  { to: '/',        label: 'Home' },
  { to: '/explore', label: 'Explore' },
  { to: '/about',   label: 'About' },
]

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const { pathname } = useLocation()

  useEffect(() => setMenuOpen(false), [pathname])

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={`sticky top-0 z-50 bg-[#fdf8f2]/95 backdrop-blur-sm border-b border-[#e8dfc8]
        transition-shadow duration-300 ${scrolled ? 'shadow-md' : 'shadow-none'}`}
    >
      <nav className="section-pad py-0">
        <div className="flex items-center justify-between h-16">

          <VanaVasLogo />

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-1">
            {links.map(({ to, label }) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/'}
                className={({ isActive }) =>
                  `px-4 py-2 rounded-full text-sm font-medium transition-all duration-150
                  ${isActive
                    ? 'bg-[#2d7a4f] text-white'
                    : 'text-[#444] hover:bg-[#e8f5ee] hover:text-[#2d7a4f]'}`
                }
              >
                {label}
              </NavLink>
            ))}
          </div>

          {/* Desktop CTA */}
          <div className="hidden md:flex items-center gap-3">
            <Link to="/login" className="text-sm font-medium text-[#444] hover:text-[#2d7a4f] transition-colors">
              Sign in
            </Link>
            <Link to="/login" className="btn-primary text-sm py-2 px-5">
              List your stay
            </Link>
          </div>

          {/* Mobile hamburger */}
          <button
            onClick={() => setMenuOpen(o => !o)}
            aria-label="Toggle menu"
            className="md:hidden flex flex-col justify-center gap-1.5 w-8 h-8 p-1"
          >
            <span className={`block h-0.5 bg-[#1c1c1c] rounded transition-all duration-200 ${menuOpen ? 'rotate-45 translate-y-2' : ''}`} />
            <span className={`block h-0.5 bg-[#1c1c1c] rounded transition-all duration-200 ${menuOpen ? 'opacity-0' : ''}`} />
            <span className={`block h-0.5 bg-[#1c1c1c] rounded transition-all duration-200 ${menuOpen ? '-rotate-45 -translate-y-2' : ''}`} />
          </button>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="md:hidden border-t border-[#e8dfc8] py-4 flex flex-col gap-2">
            {links.map(({ to, label }) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/'}
                className={({ isActive }) =>
                  `px-4 py-2.5 rounded-lg text-sm font-medium transition-colors
                  ${isActive ? 'bg-[#2d7a4f] text-white' : 'text-[#444] hover:bg-[#e8f5ee]'}`
                }
              >
                {label}
              </NavLink>
            ))}
            <div className="pt-2 border-t border-[#e8dfc8] flex flex-col gap-2">
              <Link to="/login" className="px-4 py-2.5 text-sm font-medium text-[#444]">Sign in</Link>
              <Link to="/login" className="btn-primary text-sm justify-center">List your stay</Link>
            </div>
          </div>
        )}
      </nav>
    </header>
  )
}
